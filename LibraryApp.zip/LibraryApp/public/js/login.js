let email=document.getElementById("email");
let email_error= document.getElementById("email_error");
let pwd=document.getElementById("pwd");
let error= document.getElementById("error");
let user=document.getElementById("user");
var emailvalid= false;
 var pwdvalid=false;

    email.onkeyup = function emailvalidate() {
        let regexp =/^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3}(.[a-z]{2,3}?))$/
    
    
        if(regexp.test(email.value)){
            email_error.innerHTML="VALID";
            email_error.style.color="green";
            emailvalid=true;
            }
            else {
             
                email_error.innerHTML="INVALID Login Name";
                email_error.style.color="red";
            emailvalid=false;
            }
        }
// passwrd
// When the user clicks on the password field, show the message box
pwd.onkeyup = function pwdvalidate() {
    var matchedCase = new Array();
    matchedCase.push("[$@$!%*#?&]"); // Special Charector
    matchedCase.push("[A-Z]");      // Uppercase Alpabates
    matchedCase.push("[0-9]");      // Numbers
    matchedCase.push("[a-z]");     // Lowercase Alphabates

    // Check the conditions
    var ctr = 0;
    for (var i = 0; i < matchedCase.length; i++) {
        if (new RegExp(matchedCase[i]).test(pwd.value)) {
            ctr++;
        }
    }
    // Display it
    var color = "";
    var strength = "";
    var flag=false;
    switch (ctr) {
        case 0:
        case 1:
        case 2:
            strength = "poor";
            color = "red";
            break;
        case 3:
        case 4:
            strength = "Medium";
            color = "orange";
            flag=true;
            break;
    }
    if(flag && pwd.value.length>7)
    {
        strength = "Strong";
                        color = "green";
                        pwdvalid=true;
    } else 
    pwdvalid=false;

    document.getElementById("pwd_error").innerHTML = strength;
    document.getElementById("pwd_error").style.color = color;
}
function validateform() {
    if (!emailvalid || !pwdvalid)
    {
    alert("Username/password is wrong")
    return false;}
    else
return true;

}
