const express = require('express');
const nav = [
    {link:'/library',name:'Home'},
    {link:'/books',name:'Books'},
    {link:'/authors',name:'Authors'}
];
const log = [
    {link:'/login',name:'login'},
    {link:'/signup',name:'Signup'},
    
];
const booksRouter= require ('./src/routes/bookroute')(nav,log)
const authorsRouter=require('./src/routes/authorsrouter')(nav,log)
const loginRouter=require('./src/routes/loginrouter')(nav,log)
const signupRouter=require('./src/routes/signuprouter')(nav,log)
const libraryRouter= express.Router();

const app= express();

app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views', __dirname+'/src/views');
app.use('/books',booksRouter);
app.use('/authors',authorsRouter);
app.use('/login',loginRouter);
app.use('/signup',signupRouter);
app.use('/library',libraryRouter);

// app.get('/', function(req,res){
//     res.render('library',
//     {
//         nav:[{link:'/library',name:'Home'},{link:'/books',name:'Book'},{link:'/authors',name:'Authors'}],
//        log:[{link:'/login',name:'LOGIN'},{link:'/signup',name:'SignUP'}]

//     });
// });
libraryRouter.get('/', function(req,res){
    res.render('library',
    {
       nav,
       log:[{link:'/login',name:'LOGIN'},{link:'/signup',name:'SignUP'}]

    });
});







// loginRouter.get('/login', function(req,res){
//     res.render('login',
//     {
//        nav:[{link:'/books',name:'Books'},{link:'/authors',name:'Authors'}],
//        log:[{link:'/login',name:'LOGIN'},{link:'/signup',name:'SignUP'}],
       
//     });
// });




app.listen(5000);