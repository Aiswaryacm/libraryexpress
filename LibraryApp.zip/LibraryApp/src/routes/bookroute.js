const express = require('express');
const booksRouter= express.Router();
function router(nav,log){
    var books =[
        {
            title:'The God Of Small things',
            author:'Arundati R',
            genre:'novel',
            img:'book1.jpg'
        },
        {
            title:'The White Tiger',
            author:'Aravind adiga',
            genre:'novel',
            img:'book2.jpg'
        },
        {
            title:'Manju',
            author:'M. T. Vasudevan Nair',
            genre:'novel',
            img:'book3.jpg'
        }
    
    ]
    booksRouter.get('/', function(req,res){
        res.render('books',
        {
            nav,
           log,
           books
        });
    });
    booksRouter.get('/:id', function(req,res){
        const id=req.params.id
        res.render('book',
        {
            nav,
           log,
           book:books[id]
        });
    });
    return booksRouter;
}



 module.exports=router;