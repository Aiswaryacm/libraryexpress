const express = require('express');
const signupRouter= express.Router();
function router(nav,log){
signupRouter.get('/', function(req,res){
    res.render('signup',
    {
        nav,
       log

    });
});
return signupRouter;
}
module.exports=router;